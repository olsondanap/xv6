#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main() {
	char num[] = {'1','2','3','4'};

	int temp = open("tom.txt", O_CREATE | O_RDWR);
	int size = sizeof(temp);

	printf ( 1, "Dana Olson");

	write(temp, &num, size);

	close(temp);

	exit();
}